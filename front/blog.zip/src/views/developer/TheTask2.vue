<template>
  <div class='developerTasks' id="tasks">
      <h2>悬赏任务</h2>
      <p class='developerTasksSlogan'>
        开发者社区累计拿下
        <span>{{total}}UT</span>
      </p>
      <div class='tasksContainer'>
        <el-tabs v-model="taskActive" @tab-click="handleClick">
          <el-tab-pane label="悬赏中" name="first">
            <transition name="el-fade-in-linear">
              <ul class="rewarding-list" v-if="taskActive == 'first' && abc == true">
                <li v-for="(item, index) in taskList" :key="item.index">
                  <router-link :to="{path:'/taskDetail/', query: {id: item.id, taskStatus: 0}}">
                    <h4>{{item.bountyTaskName}}</h4>
                    <i :class="['aaa', 'rewarding-icon-'+ parseInt(index+1)]" v-if="index < 8"></i>
                    <i :class="['aaa', 'rewarding-icon-'+ Math.floor(Math.random() * (7 + 1) + 1)]" v-else></i>
                    <p class="ut-count">{{item.reward}}UT</p>
                    <p class="countdown"><span v-loading="!countDownLoading"></span>
                      <count-down v-if="countDownLoading" :endTime="item.gmtPutaway" :callback="callback" :tie="item.putawayShowTime" endText="评审中"></count-down>
                    </p>
                  </router-link>
                </li>

              </ul>
            </transition>
          </el-tab-pane>
          <el-tab-pane label="开发中" name="second">
            <transition name="el-fade-in-linear">
              <ul class="developing-list" v-if="taskActive == 'second' && abc == true">
                <li v-for="item in taskList" :key="item.index" class="closed-source">
                  <router-link :to="{path:'/taskDetail/',query: {id: item.id, userId: item.receiveUserId, taskStatus: 1}}">
                    <h4>{{item.bountyTaskName}}</h4>
                    <img src="../../assets/head.png" alt="" v-if="!item.hasOwnProperty('avator')">
                    <img class="avatar" :src="item.avator" alt="" v-else>
                    <!-- <i class="avatar" v-bind:style="{ backgroundImage:`url(${ item.avator })` }"></i> -->
                    <p class="username">{{item.username}}</p>
                    <p class="state-wrap">
                      <span class="count">{{item.reward}}UT</span>
                    </p>
                  </router-link>
                </li>
              </ul>
            </transition>
          </el-tab-pane>
          <el-tab-pane label="已结束" name="third">
            <transition name="el-fade-in-linear">
              <ul class="developing-list" v-if="taskActive == 'third' && abc == true">
                <li v-for="item in taskList" :key="item.index" class="closed-source">
                  <router-link :to="{path:'/taskDetail/',query: {id: item.id,userId: item.receiveUserId, taskStatus: 2}}">
                    <h4>{{item.bountyTaskName}}</h4>
                    <img src="../../assets/head.png" alt="" v-if="!item.hasOwnProperty('avator')">
                    <img class="avatar" :src="item.avator" alt="" v-else>
                    <p class="username">{{item.username}}</p>
                    <p class="state-wrap">
                      <span class="count">{{item.reward}}UT</span>
                    </p>
                  </router-link>
                </li>
              </ul>
            </transition>
          </el-tab-pane>
        </el-tabs>
      </div>
  </div>
</template>

<script>
  import {
    getTasks,
    getReward
  } from "@/api/api";
  import {
    apiUrl
  } from "@/api/url";
  import countDown from "../../components/countDown";
  export default {
    data() {
      return {
        abc: false,
        api: apiUrl,
        taskList: [],
        taskActive: "first",
        aaa: "rewarding-icon-01",
        userId: "",
        total: "",
        countDownLoading: false,
        callback: function() {
          this.getTask(0);
        }
      };
    },
    components: {
      countDown
    },
    methods: {
      handleClick(tab, event) {
        this.getTask(tab.index);
      },
      handleClick0() {
        this.taskActive = "first";
        this.handleClick({
          index: 0
        }, event);
      },
      handleClick1() {
        this.taskActive = "second";
        this.handleClick({
          index: 1
        }, event);
      },
      handleClick2() {
        this.taskActive = "third";
        this.handleClick({
          index: 2
        }, event);
      },
      getTask(type) {
        this.abc = false;
        this.countDownLoading = false;
        this.type = type;
        getTasks(1, 100, type).then(res => {
          this.taskList = res.listTasksDos;
          this.countDownLoading = true;
          this.abc = true;
        });
      },
      getTotalReward() {
        getReward().then(res => {
          this.total = res.totalReward;
        });
      }
    },
    endM() {},
    mounted() {
      this.getTask(0);
      this.getTotalReward();
      var that = this;
      this.timer = setInterval(function() {
        that.date = new Date();
      }, 1000);
    },
    beforeDestroy() {
      if (this.timer) {
        clearInterval(this.timer); //在vue实例销毁钱，清除我们的定时器
      }
    }
  };
</script>

<style lang="scss" scoped>
  /* 悬赏任务 */
  .developerTasks {
    margin: 0 auto;
    margin-top: 18px;
    background: #FFFFFF;
    border: 1px solid #EEEEEE;
    padding: 31px 30px 0;
  }

  .developerTasks >h2 {
    font-size: 18px;
    color: #333333;
    text-align: left;
    margin: 0 0 40px;
    &::before {
      content: '';
      width: 20px;
      height: 20px;
      display: inline-block;
      background: url(../../assets/categoryname-icon02.png) no-repeat center bottom;
      background-size: 100% 100%;
      vertical-align: sub;
      margin-right: 6px;
    }
  }

  .developerTasksSlogan {
    font-size: 22px;
    color: #333333;
    text-align: left;
    display: inline-block;
    span {
      font-size: 22px;
      color: #151515;
      margin-left: 4px;
    }
  }

  .tasksContainer {
    // 悬赏中
    .rewarding-list {
      li {
        width: 255px;
        height: 332px;
        text-align: center;
        margin: 30px 27px 30px 2px;
        float: left;
        box-sizing: border-box;
        background: #FFFFFF;
        border: 1px solid #EEEEEE;
        border-radius: 6px;
        // background: url(../../assets/rewarding-bk-wanted.png) no-repeat center;
        h4 {
          padding: 0 10px;
          font-size: 18px;
          color: #333333;
          margin: 40px 0 0;
          font-weight: 600;
          overflow: hidden;
          white-space: nowrap;
          text-overflow: ellipsis;
        }
        i {
          display: inline-block;
          width: 90%;
          height: 119px;
        }
        .rewarding-icon-1 {
          background: url(../../assets/rewarding-icon-01.png) no-repeat bottom;
        }
        .rewarding-icon-2 {
          background: url(../../assets/rewarding-icon-02.png) no-repeat bottom;
        }
        .rewarding-icon-3 {
          background: url(../../assets/rewarding-icon-03.png) no-repeat bottom;
        }
        .rewarding-icon-4 {
          background: url(../../assets/rewarding-icon-04.png) no-repeat bottom;
        }
        .rewarding-icon-5 {
          background: url(../../assets/rewarding-icon-05.png) no-repeat bottom;
        }
        .rewarding-icon-6 {
          background: url(../../assets/rewarding-icon-06.png) no-repeat bottom;
        }
        .rewarding-icon-7 {
          background: url(../../assets/rewarding-icon-07.png) no-repeat bottom;
        }
        .rewarding-icon-8 {
          background: url(../../assets/rewarding-icon-08.png) no-repeat bottom;
        }
        .ut-count {
          font-family: NotoSansHans-Bold;
          font-size: 30px;
          color: #4f81f4;
          margin: 13px 0 40px;
          font-weight: 700;
          &::before {
            content: "";
            display: inline-block;
            width: 26px;
            height: 26px;
            background: url(../../assets/rewarding-icon-coin.png) no-repeat center;
            margin-right: 11px;
          }
        }
        .countdown {
          font-size: 14px;
          color: #999999;
          margin: 40px 0 30px;
        }
      }
      li:hover {
        background: #FFFFFF;
        border: 1px solid #EEEEEE;
        box-shadow: 0 0 6px 0 rgba(0, 0, 0, 0.20);
        transform: scale(1);
        transition: all .34s linear;
      }
    }
    //  开发中 已结束
    .developing-list {
      li.closed-source {
        width: 267px;
        height: 365px;
        text-align: center;
        margin-right: 28px;
        float: left;
        box-sizing: border-box;
        margin-bottom: 40px;
        h4 {
          font-family: NotoSansHans-Medium;
          font-size: 18px;
          color: #333333;
          margin: 53px 0 49px;
        }
        .avatar {
          display: inline-block;
          width: 70px;
          height: 70px;
          margin-bottom: 26px;
        }
        .username {
          font-size: 14px;
          color: #666666;
          margin-bottom: 74px;
        }
        .state-wrap {
          .state {
            font-size: 14px;
            color: #999999;
            margin-right: 21px;
            line-height: 23px;
            vertical-align: top;
            padding-right: 40px;
            height: 19px;
            border-right: 1px solid #eeeeee;
            display: inline-block;
            &::before {
              content: "";
              width: 23px;
              height: 23px;
              display: inline-block;
              border-radius: 50%;
              background: url(../../assets/closed-source.png) no-repeat center;
              margin-right: 8px;
              vertical-align: top;
            }
          }
          .count {
            font-size: 14px;
            color: #666666;
          }
        }
      }
      li.open-source {
        width: 267px;
        height: 365px;
        text-align: center;
        margin-right: 28px;
        float: left;
        box-sizing: border-box;
        margin-bottom: 40px;
        h4 {
          font-family: NotoSansHans-Medium;
          font-size: 18px;
          color: #333333;
          margin: 53px 0 49px;
        }
        .avatar {
          display: inline-block;
          width: 70px;
          height: 70px;
          background: #333;
          margin-bottom: 26px;
        }
        .username {
          font-size: 14px;
          color: #666666;
          margin-bottom: 74px;
        }
        .state-wrap {
          .state {
            font-size: 14px;
            color: #4f80f4;
            margin-right: 21px;
            line-height: 23px;
            vertical-align: top;
            padding-right: 40px;
            height: 19px;
            border-right: 1px solid #eeeeee;
            display: inline-block;
            &::before {
              content: "";
              width: 23px;
              height: 23px;
              display: inline-block;
              border-radius: 50%;
              background: url(../../assets/open-source.png) no-repeat center;
              margin-right: 8px;
              vertical-align: top;
            }
          }
          .count {
            font-size: 14px;
            color: #666666;
          }
        }
      }
      li:hover {
        border: 1px solid #979797;
        border-radius: 4px;
      }
    }
  }

  .fade-enter-active,
  .fade-leave-active {
    transition: opacity 0.9s;
  }

  .fade-enter,
  .fade-leave-to
  /* .fade-leave-active below version 2.1.8 */

  {
    opacity: 0;
  }
</style>

