<template>
  <div class="index-container">
    <div class="header-wrap">
      <top-Header></top-Header>
    </div>
    <div class='developerContainer'>
      <div class='developerBanner'>
        <div class='container'>
          <div class="developerBanner-lf-wrap">
            <h4>科技匠心  U你共创</h4>
            <p>INGENUITY FOR U</p>
          </div>
          <div class="developerBanner-rt-wrap">

          </div>
        </div>
      </div>
      <div class='developerClumn'>
        <div class="container">
          <ul class='developerClumnWrap'>
            <li>
              <a href="#document">
                <h4>开发者教程</h4>
                <ul class='developerItem'>
                  <li>
                    <a href="/#document">示范应用</a>
                  </li>
                  <li>
                    <a href="/#document">公链</a>
                  </li>
                  <li>
                    <a href="/#document">平台层</a>
                  </li>
                  <li>
                    <a href="/#document">侧链</a>
                  </li>
                </ul>
              </a>
            </li>
            <li>
              <a href="#tasks">
                <h4>悬赏任务</h4>
                <ul class='developerItem'>
                  <li>
                    <span @click="go0()">悬赏中</span>
                  </li>
                  <li>
                    <span @click="go1()"> 开发中</span>
                  </li>
                  <li>
                    <span @click="go2()">已结束</span>
                  </li>
                </ul>
              </a>
            </li>
            <li>
              <a href="#proposal">
                <h4>提案</h4>
                <ul class='developerItem'>
                  <li>
                    <a href="/proposal">提案首页</a>
                  </li>
                  <li>
                    <a href="/proposalApply">申请提案</a>
                  </li>
                </ul>
              </a>
            </li>
            <li>
              <a href="#project">
                <h4>长期项目</h4>
                <ul class='developerItem'>
                  <li>
                    <a href="/#project">安全</a>
                  </li>
                  <li>
                    <a href="/#project">测试</a>
                  </li>
                   <li>
                    <a href="/#project">翻译</a>
                  </li>
                </ul>
              </a>
            </li>
          </ul>
        </div>
      </div>
      <div class='container'>
        <div class="devloperDocuments" id="document">
          <h2>
            开发者教程
          </h2>
          <ul class="doc-list">
            <li>
              <div class="doc-icon-wrap">
                <i class="doc-icon01"></i>
              </div>
              <h4>示范应用</h4>
              <a href="https://github.com/UlordChain/ulord-blog-demo" target="blank" class="doc-title">博客Demo源码</a>
              <p class="doc-title">
                <a href="https://github.com/UlordChain/ulord-blog-demo/blob/master/README_ZH.md" target="blank">博客Demo手册</a>
                <a href="https://github.com/UlordChain/ulord-blog-demo/blob/master/README.md" target="blank">（English）</a>
              </p>
              <a href="https://ushare.org/" class="doc-title">优享</a>
            </li>
            <li>
              <div class="doc-icon-wrap">
                <i class="doc-icon02"></i>
              </div>
              <h4>Ulord公链</h4>
              <a href="http://ulord.one/whitepaper/web/viewer.html?lang=zh" target="blank" class="doc-title">技术白皮书</a>
              <a href="https://github.com/UlordChain" target="blank" class="doc-title">公链源码</a>
              <p class="doc-title">
                <a href="https://github.com/UlordChain/Document/blob/master/UlordChain%20%E5%90%84%E4%B8%AA%20Repository%E4%BB%8B%E7%BB%8D.md" target="blank">Github库概览</a>
                <a href="https://github.com/UlordChain/Document/blob/master/Brief%20Introduction%20of%20Each%20Repository%20.md" target="blank">（English）</a>
              </p>
            </li>
            <li>
              <div class="doc-icon-wrap">
                <i class="doc-icon03"></i>
              </div>
              <h4>平台层</h4>
              <a href="https://github.com/UlordChain/Ulord-platform/blob/master/README_zh.md" target="blank" class="doc-title">平台层架构介绍</a>
              <a href="https://github.com/UlordChain/Ulord-platform/blob/master/doc/ulord_paas_zh.md" target="blank" class="doc-title">UPaaS介绍</a>
              <p class="doc-title">
                <a href="https://github.com/UlordChain/Ulord-platform/blob/master/Uwallet/uwallet_api.md" target="blank">UCwallet API（Python）</a>
                <a href="https://github.com/UlordChain/Ulord-platform/blob/wallet_cx/upaas/ucwallet-sdk/ReadMe_zh.md" target="blank">（JAVA）</a>
              </p>
              <a href="https://github.com/UlordChain/Ulord-platform/blob/master/doc/ulord_platform_service_zh.md" target="blank" class="doc-title">Ulord平台服务API</a>
            </li>
            <li>
              <i class="doc-icon04"></i>
              <h4>Ulord侧链</h4>
              <a href="https://github.com/UlordChain/Ulord-Sidechain" target="blank" class="doc-title">Ulord侧链介绍</a>
              <a href="https://github.com/UlordChain/Ulord-Sidechain-SDK" target="blank" class="doc-title">Ulord侧链SDK</a>
              <a href="https://github.com/UlordChain/Ulord-Sidechain-SDK/blob/master/deploy.md" target="blank" class="doc-title">USC智能合约一键部署</a>
            </li>
          </ul>
        </div>
        <the-task2 ref="child"></the-task2>
        <div class='developerProposal' id="proposal">
          <h2>提案管理</h2>
          <p class='developerProposalSlogan'> 区块高度为{{ proposalData.currentBlockHeight }}</p>
          <ul class='dp-ListWrap'>
            <li v-for="(item,index) in proposalData.proposalDoList" v-bind:key="index" v-bind:class="{ 'dp-ItemIng': item.periodStatus == 0,'dp-ItemPassed': item.periodStatus == 1,'dp-ItemFail':item.periodStatus == 2}">
              <div @click="goDetail(item.proposalId, item.displayName, item.periodStatus)" style="cursor: pointer">
                <div class="proposal-name-wrap">
                  <div class="proposal-name">{{ item.proposalName||'无标题' }}</div>
                </div>

                <p class='dp-word'>
                  {{ item.digest }}
                </p>
                <p class='dp-voteState'>
                  <span>投票</span>
                  <b v-if="item.periodStatus == 0">（已通过）</b>
                </p>
                <div class='dp-progressbar'>
                  <el-progress :text-inside="true" :percentage="item.voteNumYes | progress(proposalData.majorNodeCount)" status="success" v-if="item.periodStatus == 0"></el-progress>
                  <el-progress :text-inside="true" :percentage="item.voteNumYes | progress(proposalData.majorNodeCount)" v-else-if="item.periodStatus == 1"></el-progress>
                  <el-progress :text-inside="true" :percentage="item.voteNumYes | progress(proposalData.majorNodeCount)" status="exception" v-else-if="item.periodStatus == 2"></el-progress>
                  <!-- <el-progress :percentage="item.voteNumYes | progress(proposalData.majorNodeCount)"></el-progress> -->
                </div>
              </div>
              <div class='dp-consequenceWrap'>
                <div class='dp-consequenceLf'>
                  <span>投票：</span> &nbsp;
                  <span>{{ item.voteNumYes }}</span>
                </div>
                <div class='dp-consequenceRt'>
                  <i class="avatar" v-bind:style="{ backgroundImage:`url(${ item.avator })` }"></i>
                  <span>{{ item.displayName }}</span>
                </div>
              </div>
            </li>
          </ul>
          <div class="dp-detailmore-wrap">
             <router-link to="/proposal">
              <a class="dp-detailmore">查看更多 ></a>
            </router-link>
          </div>
        </div>
        <div class='developerProjects' id="project">
          <h2>长期项目</h2>
          <div class="project-content-wrap">
            <div class="pro-lf-wrap">
              <div class="safe">
                <h2>安全</h2>
                <div>
                  <p>利用形式化证明的方式证明共识算法Cryptohello的安全性</p>
                </div>
              </div>
              <div class="link-list">
                <div class="col-list mar30b">
                  <a href="https://github.com/UlordChain/node-multi-hashing" target="blank">算法代码 ></a>
                  <a href="https://github.com/UlordChain/Document/blob/master/CryptoHello_zh.md" target="blank">算法文档 ></a>
                </div>
                 <p class="safe-tip">发现安全漏洞，成为Ulord网络安全的守护人 (高危 1500 UT, 中危 500 UT, 低危 100 UT)</p>
                <div class="col-list">
                   <a href="https://github.com/UlordChain/UlordChain" target="blank">主网 ></a>
                  <a href="https://github.com/UlordChain/Uwallet" target="blank">钱包 ></a>
                   <a href="https://github.com/UlordChain/ulordrig" target="blank">挖矿客户端 ></a>
                </div>
                <div class="col-list">
                   <a href="https://github.com/UlordChain/Ulord-Sidechain" target="blank">侧链 ></a>
                  <a href="https://github.com/UlordChain/insight-ui-ulord" target="blank">浏览器 ></a>
                </div>
              </div>
              <div class="mailbox">
                注：为避免漏洞被利用，请将描述及重现步骤发送至邮箱<a href="http://mailto:dev@ulord.one" target="blank">dev@ulord.one</a>
              </div>
            </div>
            <div class="pro-rt-wrap">
              <div class="test">
                <h2>工程</h2>
                <div class="pro-rt-content">
                  <div>
                      <p class="mar3t">
                        <span>与开发人员一起参与测试，使Ulord链更健壮！</span>
                        <a href="https://github.com/UlordChain/UlordChain/tree/master/src/test" target="blank">了解详情 ></a>
                      </p>
                  </div>
                  <div class="mar38b">
                      <p>
                        <span>帮助Uolrd提高性能！</span>
                        <a href="https://github.com/UlordChain/UlordChain/pull/35" target="blank">了解详情 ></a>
                      </p>
                  </div>
                </div>

              </div>
               <div class="translate">
                 <h2>翻译</h2>
                 <div class="pro-rt-content">
                    <div>
                      好的东西要与大家分享，将 Ulord技术文档翻译成各种语言！
                    </div>
                    <div>
                      <a href="javascript:;" class="language-type">英文 ></a>
                      <a href="javascript:;" class="language-type">日文 ></a>
                      <a href="javascript:;" class="language-type" >韩文 ></a>
                      <a href="javascript:;" class="language-type">俄文 ></a>
                    </div>
                    <div class="mailbox">
                       注：文章翻译后发送至邮箱 <a href="http://mailto:dev@ulord.one" target="blank">dev@ulord.one</a> ，邮件标题：技术翻译 + 语言
                    </div>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class='developerFooter'>
          <router-link to="/">
            <i class="footer-logo"></i>
          </router-link>
          <p class='dlf-copyright'>Copyright &copy; 2017-2018 ulorder.one</p>
        </div>
    </div>
  </div>
</template>

<script>
import { home } from "@/api/api";
import { getAllProposal } from "@/api/api";
import TheTask2 from "./TheTask2.vue";
import { apiUrl } from "@/api/url";
import { HappyScroll } from "vue-happy-scroll";
import "vue-happy-scroll/docs/happy-scroll.css";
export default {
  name: "developer",
  beforeCreate() {
    document.querySelector("body").setAttribute("style", "background:#f5f5f5");
  },
  beforeDestroy() {
    document.querySelector("body").setAttribute("style", "");
  },
  data() {
    return {
      proposalData: {},
      api: apiUrl
    };
  },
  filters: {
    progress(value, acount) {
      if (acount == 0) {
        return 0;
      } else {
        return Math.floor(value / acount * 100);
      }
    },
    pp(value) {
      if (value == 0) {
        return "（投票中）";
      } else if (value == 1) {
        return "（已通过）";
      } else if (value == 2) {
        return "（未通过）";
      }
    }
  },
  created() {},
  methods: {
    goDetail(id, name, status) {
      this.$router.push({
        path: "/proposalDetail",
        query: {
          id: id,
          name: name,
          status: status
        }
      });
    },
    go0() {
      this.$refs.child.handleClick0();
    },
    go1() {
      this.$refs.child.handleClick1();
    },
    go2() {
      this.$refs.child.handleClick2();
    }
  },
  components: {
    HappyScroll,
    TheTask2
  },
  mounted() {
    getAllProposal(0, 6, 1).then(res => {
      this.proposalData = res;
    });
  }
};
</script>

<style rel="stylesheet/scss" lang="scss">
.index-container {
  // tabs start
  .el-tabs__nav {
    float: right;
  }
  // .el-tabs__active-bar,
  // .el-tabs__nav-wrap::after {
  //   display: none;
  // }
  .el-tabs__item {
    font-size: 14px;
    color: #666;
  }
  .el-tabs__item.is-active {
    font-size: 16px;
    color: #4f81f4;
  }
  .el-tabs__nav-wrap::after {
    background-color: #eee;
  }
  // .el-tabs__content {
  //   min-height: 405px;
  // }
  .el-tabs__active-bar {
    background-color: #4f81f4;
  }
  .is-success .el-progress-bar__inner {
    background-color: #4f81f4;
  }
  // tabs end
}
</style>

<style rel="stylesheet/scss" lang="scss" scoped>
  .index-container {
     width: 100%;
    height: 100%;
    background: #f5f5f5;
    .container {
      width: 1200px;
      margin: 0 auto;
      position: relative;
    }
    .developerContainer {
      width: 100%;
      height: 100%;
      background: #f5f5f5;
      .developerBanner {
        width: 100%;
        height: 523px;
        background: #0e0f12;
        background-size: 100% 100%;
        padding-top: 54px;
        .developerBanner-lf-wrap {
          display: inline-block;
          width: 50%;
          height: 523px;
          float: left;
          h4 {
            line-height: 64px;
            font-size: 54px;
            color: #fff;
            margin-top: 30%;
            letter-spacing: 18px;
          }
          p {
            line-height: 40px;
            font-size: 32px;
            color: #fff;
            margin-top: 40px;
            letter-spacing: 10px;
          }
          .more {
            color: #fff;
            width: 130px;
            height: 36px;
            display: block;
            font-size: 14px;
            line-height: 36px;
            -webkit-border-radius: 0;
            -moz-border-radius: 0;
            border-radius: 0;
            border: 1px solid #fff;
            text-align: center;
            margin-top: 60px;
          }
        }
        .developerBanner-rt-wrap {
          display: inline-block;
          width: 50%;
          height: 523px;
          background: url(../../assets/banner-rt.png) no-repeat center;
          background-size: 372px 377px;
        }
      }
      // 模块
      .developerClumn {
        width: 100%;
        height: 80px;
        background: #ffffff;
        overflow: hidden;
      }
      .developerClumnWrap{
        padding: 0 30px;
        height: 80px;
      }
      .developerClumnWrap>li {
          width: 25%;
          float: left;
          padding: 14px 0;
      }
      .developerClumnWrap>li:first-child a{
          padding-left: 0;
      }
      .developerClumnWrap>li>a {
        display: inline-block;
        padding-left: 30px;
      }
      .developerClumn h4 {
        font-size: 16px;
        color: #666666;
        margin-bottom: 10px;
        &:hover {
          color: #4f81f4;
        }
      }
      .developerItem>li {
        float: left;
        padding-right: 20px;
      }
      .developerItem>li:last-child {
        padding-right: none;
      }
      .developerItem>li a,
      .developerItem>li span {
        font-size: 14px;
        color: #999999;
        &:hover {
          color: #4f81f4;
        }
      }
      // 文档
      .devloperDocuments {
        margin: 0 auto;
        height: 358px;
        margin-top: 18px;
        background: #ffffff;
        border: 1px solid #eeeeee;
        padding: 31px 30px;
        &>h2 {
          font-size: 18px;
          color: #333333;
          text-align: left;
          margin: 0 0 41px;
          &::before {
            content: "";
            width: 20px;
            height: 20px;
            display: inline-block;
            background: url(../../assets/categoryname-icon01.png) no-repeat center bottom;
            background-size: 100% 100%;
            vertical-align: sub;
            margin-right: 6px;
          }
        }
        .doc-list {
          li {
            width: 25%;
            min-height: 278px;
            float: left;
            border-left: 1px solid #eee;
            box-sizing: border-box;
            padding-left: 30px;
            &:first-child {
              border: none;
              padding-left: 0;
            }
            .doc-icon-wrap{

            }
            i{
              width: 68px;
              height: 68px;
            }
            .doc-icon01 {
              display: inline-block;
              background: url(../../assets/doc-icon01.png) no-repeat left bottom;
              background-size: 100% 100%;
            }
            .doc-icon02 {
              display: inline-block;
              background: url(../../assets/doc-icon02.png) no-repeat left bottom;
              background-size: 100% 100%;
            }
            .doc-icon03 {
              display: inline-block;
              background: url(../../assets/doc-icon03.png) no-repeat left bottom;
              background-size: 100% 100%;
            }
            .doc-icon04 {
              display: inline-block;
              background: url(../../assets/doc-icon04.png) no-repeat left bottom;
               background-size: 100% 100%;
            }
            h4 {
              font-size: 22px;
              color: #444444;
              margin: 20px 0 30px;
            }
            .doc-title {
              display: block;
              font-size: 14px;
              color: #666666;
              margin-bottom: 14px;
              &:hover {
                font-size: 14px;
                color: #4f81f4;
              }
              a {
                font-size: 14px;
                color: #666666;
                &:hover {
                  font-size: 14px;
                  color: #4f81f4;
                }
              }
            }
          }
        }
      }
      /* 提案管理 */
      .developerProposal {
        clear: both;
        margin: 0 auto;
        margin-top: 18px;
        background: #ffffff;
        border: 1px solid #eeeeee;
        padding: 31px 30px 0;
      }
      .developerProposal h2 {
        font-size: 18px;
        color: #333333;
        text-align: left;
        margin: 0 0 40px;
        &::before {
          content: "";
          width: 20px;
          height: 20px;
          display: inline-block;
          background: url(../../assets/categoryname-icon03.png) no-repeat center bottom;
          background-size: 100% 100%;
          vertical-align: sub;
          margin-right: 6px;
        }
      }
      .developerProposalSlogan {
        margin: 0 auto;
        text-align: left;
        font-size: 22px;
        color: #444444;
        margin-bottom: 40px;
      }
      .dp-ListWrap {
        width: 100%;
        margin: 0 auto;
      }
      .dp-ListWrap li {
        margin: 0 auto;
        float: left;
        margin-right: 42px;
        width: 350px;
        height: 480px;
        margin-bottom: 20px;
        box-sizing: border-box;
        background: #FFFFFF;
        border: 1px solid #EEEEEE;
        border-radius: 6px;
      }
      .dp-ListWrap li:hover {
        background: #FFFFFF;
        border: 1px solid #EEEEEE;
        box-shadow: 0 0 10px 0 rgba(0, 0, 0, 0.20);
        border-radius: 6px;
         transform: scale(1);
        transition: all .34s linear;
      }
      .dp-ListWrap li:nth-child(3),
      .dp-ListWrap li:nth-child(6),
      .dp-ListWrap li:nth-child(9),
      .dp-ListWrap li:nth-child(12) {
        margin-right: 0;
      }
      .dp-ListWrap li:last-child {
        margin-right: 0;
      }
      .proposal-name-wrap {
        border-radius:: 6px 6px 0 0;
        width: 100%;
        height: 200px;
        overflow: hidden;
        text-overflow: ellipsis;
        background: url(../../assets/proposal-bk.png) no-repeat center;
        background-size: 100% 100%;
        .proposal-name {
          font-size: 22px;
          color: #FFFFFF;
          height: 80px;
          line-height: 40px;
          margin: 70px 0 50px;
          padding: 0 30px;
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-line-clamp: 2;
           /*! autoprefixer: off */
          -webkit-box-orient: vertical;
          /* autoprefixer: on */
          word-break: break-word;
        }
      }
      .dp-ListWrap li .dp-word {
        font-size: 14px;
        color: #282828;
        text-align: justify;
        height: 94px;
        line-height: 23px;
        margin: 20px 0 20px;
        padding: 0 30px;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 4;
          /*! autoprefixer: off */
        -webkit-box-orient: vertical;
          /* autoprefixer: on */
        word-wrap: break-word;
      }
      /* 投票状态 start*/
      .dp-progressbar {
        padding: 0 30px;
        width: 290px;
        border-radius: 47px;
        margin-top: 14px;
        margin-bottom: 32px;
      }
      .dp-voteState{
        padding: 0 30px;
        span::before{
          content:'';
          width: 20px;
          height: 20px;
          display: inline-block;
          margin-right: 6px;
          background: url(../../assets/proposal-underway.png) no-repeat center;
          vertical-align: bottom;
        }
      }
      /* 已通过 */
      .dp-ItemPassed .dp-voteState span {
        font-size: 14px;
        color: #5A8CF5;
      }
      .dp-ItemPassed .dp-voteState b {
        font-size: 14px;
        color: #999999;
        font-weight: normal;
        margin-left: 5px;
      }
      .dp-ItemPassed .dp-progress {
        width: 176px;
        height: 6px;
        background: #4f81f4;
        border-radius: 47px;
      }
      /* 投票中 */
      .dp-ItemIng .dp-voteState span {
        font-size: 14px;
        color: #5A8CF5;
      }
      .dp-ItemIng .dp-voteState b {
        display: none;
      }
      .dp-ItemIng .dp-progress {
        width: 176px;
        height: 6px;
        background: #4f81f4;
        border-radius: 47px;
      }
      /* 未通过 */
      .dp-ItemFail .dp-voteState span {
        font-size: 14px;
        color: #999;
      }
      .dp-ItemFail .dp-voteState b {
        display: none;
      }
      .dp-ItemFail .dp-progress {
        width: 176px;
        height: 6px;
        background: #999;
        border-radius: 47px;
      }
      /* 投票状态 end*/
      .dp-consequenceWrap {
        border-top: 1px solid #eeeeee;
        overflow: hidden;
         box-sizing: border-box;
         padding: 15px 0;
      }
      .dp-consequenceLf {
        display: inline-block;
        width: 48%;
        height: 30px;
        line-height: 30px;
        margin: 0 auto;
        text-align: center;
        border-right: 1px solid #eeeeee;
         box-sizing: border-box;
      }
      .dp-consequenceLf span {
        font-size: 14px;
        color: #4f81f4;
      }
      .dp-consequenceRt {
        display: inline-block;
        width: 48%;
        height: 30px;
        line-height: 30px;
        margin: 0 auto;
        text-align: center;
        box-sizing: border-box;
      }
      .dp-consequenceRt .avatar {
        display: inline-block;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background-size: 100%;
        background-position: center;
        background-repeat: no-repeat;
        margin-right: 20px;
        vertical-align: middle;
      }
      .dp-consequenceRt span {
        width: 70px;
        display: inline-block;
        margin: 0 auto;
        text-align: center;
        font-size: 14px;
        color: #999999;
        vertical-align: top;
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
      }
      .dp-detailmore-wrap{
         clear: both;
         text-align: left;
          padding: 40px 30px 30px;
        .dp-detailmore {
          display: inline-block;
          font-size: 18px;
          color: #4F80F4;

        }
      }

      /* 长期项目 */
      .developerProjects {
        height: 415px;
        background: #FFFFFF;
        border: 1px solid #EEEEEE;
        margin-top: 20px;
        clear: both;
        padding: 31px 30px 0;
        margin-bottom: 121px;
        &>h2{
          font-size: 18px;
          color: #333333;
          text-align: left;
          margin: 0 0 40px;
          &::before {
            content: "";
            width: 20px;
            height: 20px;
            display: inline-block;
            background: url(../../assets/categoryname-icon04.png) no-repeat center bottom;
            background-size: 100% 100%;
            vertical-align: sub;
            margin-right: 6px;
          }
        }
        .project-content-wrap{
          padding-bottom: 30px;
          .pro-lf-wrap{
            width: 49%;
            box-sizing: border-box;
            overflow: hidden;
            display: inline-block;
            border-right: 1px solid #eee;
            float: left;
            .safe{
              &>h2{
                font-size: 22px;
                color: #333333;
                display: inline-block;
                margin-bottom: 0;
                vertical-align: unset;
              }
              &>div{
                width: 418px;
                display: inline-block;
                margin-left: 30px;
                p{
                  font-size: 16px;
                  color: #333333;
                  line-height: 26px;
                }
              }
            }
            .link-list{
              padding-left: 79px;
              margin-top: 20px;
              .col-list{
                margin-bottom: 20px;
                a{
                  width:108px;
                  font-size: 16px;
                  color: #4F81F4;
                  display: inline-block;
                  margin-right: 47px;
                }
              }
              .mar30b{
                 margin-bottom: 30px;
              }
            }
            .safe-tip{
                width: 418px;
                font-size: 16px;
                color: #333333;
                letter-spacing: 0.43px;
                line-height: 26px;
                margin-bottom: 20px;
              }
            .mailbox{
              margin-top: 39px;
              padding-left: 79px;
              font-size: 12px;
              color: #999999;
                a{
                  height: 14px;
                  display: inline-block;
                  font-size: 12px;
                  color: #999999;
                }
            }
          }
          .pro-rt-wrap{
            width: 49%;
            box-sizing: border-box;
            display: inline-block;
            padding-left: 30px;
           .test{
              border-bottom: 1px solid #eee;
              box-sizing: border-box;
              &>h2{
                font-size: 22px;
                color: #333333;
                display: inline-block;
                margin-bottom: 0;
                vertical-align: top;
              }
              .pro-rt-content{
                display: inline-block;
                width: 90%;
                &>div{
                  display: inline-block;
                  margin: 0 0 30px 30px;
                  p{
                    span{
                      width: 331px;
                      font-size: 16px;
                      color: #333333;
                      line-height: 26px;
                      display: inline-block;
                    }
                    a{
                      font-size: 16px;
                      color: #4F81F4;
                      line-height: 16px;
                      display: inline-block;
                      margin-left: 14px;
                    }
                  }
                }
                .mar38b{
                  margin-bottom: 38px;
                }
                .mar3t{
                  margin-top: 3px;
                }
              }
            }
            .translate{
              padding-top: 30px;
              &>h2{
                font-size: 22px;
                color: #333333;
                display: inline-block;
                margin-bottom: 0;
                vertical-align: top;
              }
              .pro-rt-content{
                display: inline-block;
                width: 90%;
                &>div{
                  display: inline-block;
                  margin: 7px 0 30px 30px;
                  p{
                    span{
                      width: 331px;
                      font-size: 16px;
                      color: #333333;
                      line-height: 26px;
                      display: inline-block;
                    }
                    a{
                      font-size: 16px;
                      color: #4F81F4;
                      line-height: 16px;
                      display: inline-block;
                      margin-left: 14px;
                    }
                  }
                }

                .mailbox{
                  margin: 0 0 0 30px;
                  font-size: 12px;
                  color: #999999;
                    a{
                      height: 14px;
                      display: inline-block;
                      font-size: 12px;
                      color: #999999;
                    }
                }
                .language-type{
                  width: 66px;
                  display: inline-block;
                  font-size: 16px;
                  color: #999999;
                  line-height: 16px;
                  cursor: inherit;
                }
              }
            }
          }
        }
      }

      //  footer
      .developerFooter {
        width: 100%;
        height: 209px;
        background: #333;
        padding-top: 30px;
      }
      .developerFooter .container {
        border-top: 1px solid #999999;
      }
      .footer-logo {
        width: 22px;
        height: 44px;
        margin: 0 auto;
        display: block;
        background: url(../../assets/logo-footer.png) no-repeat center;
        margin-top: 33px;
      }
      .dlf-copyright {
        margin: 0 auto;
        text-align: center;
        font-size: 14px;
        color: #666666;
        padding-top: 34px;
      }
    }
  }


/*=============================================
              (max-width: 1023px)
  =============================================*/

@media all and (max-width: 1023px) {
  .index-container .developerContainer .developerBanner,.index-container .developerContainer .developerClumn{
    width: 1200px;
  }
}
</style>
