<template>
  <div class='developerTasks'>
    <div  class='container'>
      <h2>悬赏任务</h2>
      <p class='developerTasksSlogan'>开发者社区累计拿下 88,000,000UT</p>
      <div class='tasksContainer'>
        <div class='tasksTabTitle'>
            <ul class='tasksSwitcher clearfix'>
                <li :class="[type === 0 ? 'tasks-item active' : 'tasks-item']" @click="getTask(0)">
                    悬赏中
                </li>
                <li :class="[type === 1 ? 'tasks-item active' : 'tasks-item']" @click="getTask(1)">
                    开发中
                </li>
                <li :class="[type === 2 ? 'tasks-item active' : 'tasks-item']" @click="getTask(2)">
                    已结束
                </li>
            </ul>
        </div>
        <div class='tasksList'>
          <div>
            <transition name="fade">
            <ul class='d-taskContentWrap' v-if="isRouterAlive">
                <li v-for="item in taskList" v-bind:key="item.id" class="list-complete-item">
                    <div class='d-taskContent'>
                        <h4>{{item.bountyTaskName}}</h4>
                        <router-link v-if="type === 0" :to="{path:'/taskDetail/', query: {id: item.id}}" class='d-getTask'>领取</router-link>
                        <router-link v-else-if="type === 1" :to="{path:'/taskDetail/', query: {id: item.id, userId: item.receiveUserId}}" class='d-getTask'>查看</router-link>
                        <router-link v-else-if="type === 2" :to="{path:'/taskDetail/', query: {id: item.id, userId: item.receiveUserId}}" class='d-getTask'>查看</router-link>
                    </div>
                    <div class='d-taskCoin'>
                        <span>{{item.reward}}UT</span>
                    </div>
                </li>
            </ul>
          </transition>
        </div>
      </div>
    </div>
  </div>
</div>
</template>
<script>
import { getTasks } from '@/api/api'
import { getId} from '@/utils/auth'
export default {
  name: 'TheTask',
  data() {
    return {
      type: 0,
      userId: getId(),
      isRouterAlive: true,
      taskList: []
    }
  },
  methods: {
    getTask(type) {
      var that = this;
      this.type = type;
      getTasks(1,8,type).then(function(res) {
      that.taskList = res.listTasksDos;
      that.isRouterAlive = false
      that.$nextTick(() => (that.isRouterAlive = true))
      })
    }
  },
  mounted() {
    this.getTask(this.type);
  },
  
}
</script>
<style lang="scss" scoped>
  .developerTasks{
     width: 100%;
     margin: 0 auto;
 }
 .developerTasks h2{
     font-size: 50px;
     color: #282828;
     text-align: center;
 }
 .developerTasksSlogan{
     font-size: 16px;
     color: #999999;
     text-align: center;
     margin-top: 20px;
 }
 /* 悬赏任务 */
 .tasksTabTitle {
     position: relative;
 }
 .tasksSwitcher{
     float: right;
     margin-top: 19px;
     margin-bottom: 59px;
 }
 .tasksSwitcher .tasks-item {
   transition: all .3s;
     float: left;
     width: 108px;
     height: 27px;
     line-height: 27px;
     font-size: 14px;
     color: #666666;
     cursor: pointer;
     text-align: center;
 }
 
 .tasksSwitcher .tasks-item.active {
     background: #4F81F4;
     color: #FFFFFF;
 }
 .tasksList {
     height: 500px;
 }
 .d-taskContentWrap {
     width: 100%;
     margin-top: 59px;
     clear: both;
    
 }
 .d-taskContentWrap li{
     width: 200px;
     height: 284px;
     margin-right: 133px;
     background: #FFFFFF;
     border-radius: 4px;
     position: relative;
     float: left;
     margin-bottom: 49px;
 }
 .d-taskContentWrap li:last-child {
   margin-right: 0;
 }
 .d-taskContentWrap li:hover{
     box-shadow: 0 10px 5px rgba(224,224,224,.7);
 }
 .d-taskContent{
     margin-left: 17px;
     border-left: 1px solid #F1F0F0;
     height: 284px;
 }
 .d-taskCoin{
     width: 169px;
     height: 65px;
     text-align: center;
     background: #F2F2F2;
     position: absolute;
     top: 50%;
     left: 0;
     transform: translate(0,-50%);
 }
 .d-taskCoin span{
     font-size: 18px;
     color: #4F81F4;
     margin: 21px 0 26px;
     display: block;
 }
 .d-taskContent h4{
     font-size: 18px;
     color: #444444;
     padding: 49px 0 54px 18px;
 }
 .d-getTask{
     margin: 0 auto;
     width: 132px;
     height: 40px;
     line-height: 40px;
     background: #FFFFFF;
     border: 1px solid #4F80F4;
     border-radius: 4px;
     font-size: 14px;
     color: #4F80F4;
     text-align: center;
     margin-top: 224px;
     display: block;
     position: absolute;
     bottom: 20px;
     left: 36px;
 }
 .d-getTask:hover{
     background: #4F80F4;
     font-size: 14px;
     color: #FFFFFF;
 }
.fade-enter-active, .fade-leave-active {
  transition: opacity .9s;
}
.fade-enter, .fade-leave-to /* .fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}
</style>
