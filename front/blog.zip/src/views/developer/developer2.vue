<template>
<div>
    <div class="header-wrap">
        <top-Header></top-Header>
    </div>
    
  <div class='developerContainer'>
    <div class='developerBanner'>
    </div>
    <div class='developerClumn'>
        <div class='container'>
            <ul class='developerClumnWrap'>
                <li>
                    <h4>开发者教程</h4>
                    <ul class='developerItem'>
                        <li>
                            <a>快速开始</a>
                        </li> 
                        <li>
                            <a>开发环境</a>
                        </li> 
                        <li>
                            <a>研发动态</a>
                        </li> 
                    </ul>
                </li>
                <li>
                    <h4>悬赏任务</h4>
                    <ul class='developerItem'>
                        <li>
                            <a>悬赏中</a>
                        </li> 
                        <li>
                            <a> 开发中</a>
                        </li> 
                        <li>
                            <a>已结束</a>
                        </li> 
                    </ul>
                </li>
                <li>
                    <h4>提案</h4>
                    <ul class='developerItem'>
                        <li>
                            <a>提案投票</a>
                        </li> 
                        <li>
                            <a>提案申请</a>
                        </li> 
                    </ul>
                </li>
                <li>
                    <h4>长期项目</h4>
                    <ul class='developerItem'>
                        <li>
                            <a>算法</a>
                        </li> 
                        <li>
                            <a>测试</a>
                        </li> 
                    </ul>
                </li>
            </ul>
        </div>
    </div>
    <div class='developerTutorial'>
        <div  class='container'>
            <h2>开发者教程</h2>
            <ul class='dtItemContainer'>
                <li>
                    <i class='dtItem-img01'></i>
                    <h4>快速开始</h4>
                    <ul class='dtItemWrap'>
                        <li>
                            
                                <a>了解Ulord技术白皮书</a>
                            
                        </li>
                        <li>
                            
                                <a>了解Ulord技术白皮书</a>
                        
                        </li>
                        <li>
                            
                                <a>了解Ulord技术白皮书</a>
                            
                        </li>
                        <li>
                            
                                <a>了解Ulord技术白皮书</a>
                            
                        </li>
                    </ul>
                    
                        <a class='dtItemMore'>更多</a>
                    
                </li>
                <li>
                    <i class='dtItem-img02'></i>
                    <h4>开发环境</h4>
                    <ul class='dtItemWrap'>
                        <li>
                            
                                <a>了解Ulord技术白皮书</a>
                            
                        </li>
                        <li>
                            
                                <a>了解Ulord技术白皮书</a>
                            
                        </li>
                        <li>
                            
                                <a>了解Ulord技术白皮书</a>
                            
                        </li>
                        <li>
                            
                                <a>了解Ulord技术白皮书</a>
                            
                        </li>
                    </ul>
                    
                        <a class='dtItemMore'>更多</a>
                    
                </li>
                <li>
                    <i class='dtItem-img03'></i>
                    <h4>研发动态</h4>
                    <ul class='dtItemWrap'>
                        <li>
                            
                                <a>了解Ulord技术白皮书</a>
                            
                        </li>
                        <li>
                            
                                <a>了解Ulord技术白皮书</a>
                            
                        </li>
                        <li>
                            
                                <a>了解Ulord技术白皮书</a>
                            
                        </li>
                        <li>
                            
                                <a>了解Ulord技术白皮书</a>
                            
                        </li>
                    </ul>
                    
                        <a classs='dtItemMore'>更多</a>
                    
                </li>
            </ul>
        </div>
    </div>                    
    
    <div class='developerProposal'>
        <div class='container'>
            <h2>提案管理</h2>
            <p class='developerProposalSlogan'>本轮投票截止日期为22天 区块高度为1208</p>
            <ul class='dp-ListWrap'>
                <li class='dp-ItemPassed'>
                    <div class='dp-Padding'>
                        <h4>为Ulord侧链开发基于LLVW的可修改智能合约</h4>
                        <p class='dp-word'>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.
                        </p>
                        <p class='dp-voteState'>
                            <span>投票</span>
                            <b>（已通过）</b>
                        </p> 
                        <div class='dp-progressbar'>
                            <div class='dp-progress'></div>
                        </div>
                    </div>  
                    <div class='dp-consequenceWrap'>
                        <div class='dp-consequenceLf'>
                            <span>投票中：</span> &nbsp;
                            <span>378</span>
                        </div>
                        <div class='dp-consequenceRt'>
                            <span>来源于：</span> &nbsp;
                            <span>cyy</span>
                        </div>
                    </div>
                </li>
                <li class='dp-ItemIng'>
                    <div class='dp-Padding'>
                        <h4>为Ulord侧链开发基于LLVW的可修改智能合约</h4>
                        <p class='dp-word'>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.
                        </p>
                        <p class='dp-voteState'>
                            <span>投票</span>
                            
                        </p> 
                        <div class='dp-progressbar'>
                            <div class='dp-progress'></div>
                        </div>
                    </div>  
                    <div class='dp-consequenceWrap'>
                        <div class='dp-consequenceLf'>
                            <span>投票中：</span> &nbsp;
                            <span>378</span>
                        </div>
                        <div class='dp-consequenceRt'>
                            <span>来源于：</span> &nbsp;
                            <span>cyy</span>
                        </div>
                    </div>
                </li>
                <li class='dp-ItemIng'>
                    <div class='dp-Padding'>
                        <h4>为Ulord侧链开发基于LLVW的可修改智能合约</h4>
                        <p class='dp-word'>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.
                        </p>
                        <p class='dp-voteState'>
                            <span>投票</span>
                            
                        </p> 
                        <div class='dp-progressbar'>
                            <div class='dp-progress'></div>
                        </div>
                    </div>  
                    <div class='dp-consequenceWrap'>
                        <div class='dp-consequenceLf'>
                            <span>未通过：</span> &nbsp;
                            <span>378</span>
                        </div>
                        <div class='dp-consequenceRt'>
                            <span>来源于：</span> &nbsp;
                            <span>cyy</span>
                        </div>
                    </div>
                </li>
                <li class='dp-ItemFail'>
                    <div class='dp-Padding'>
                        <h4>为Ulord侧链开发基于LLVW的可修改智能合约</h4>
                        <p class='dp-word'>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.
                        </p>
                        <p class='dp-voteState'>
                            <span>投票</span>
                            
                        </p> 
                        <div class='dp-progressbar'>
                            <div class='dp-progress'></div>
                        </div>
                    </div>  
                    <div class='dp-consequenceWrap'>
                        <div class='dp-consequenceLf'>
                            <span>投票中：</span> &nbsp;
                            <span>378</span>
                        </div>
                        <div class='dp-consequenceRt'>
                            <span>来源于：</span> &nbsp;
                            <span>cyy</span>
                        </div>
                    </div>
                </li>
                <li class='dp-ItemIng'>
                    <div class='dp-Padding'>
                        <h4>为Ulord侧链开发基于LLVW的可修改智能合约</h4>
                        <p class='dp-word'>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.
                        </p>
                        <p class='dp-voteState'>
                            <span>投票</span>
                            
                        </p> 
                        <div class='dp-progressbar'>
                            <div class='dp-progress'></div>
                        </div>
                    </div>  
                    <div class='dp-consequenceWrap'>
                        <div class='dp-consequenceLf'>
                            <span>投票中：</span> &nbsp;
                            <span>378</span>
                        </div>
                        <div class='dp-consequenceRt'>
                            <span>来源于：</span> &nbsp;
                            <span>cyy</span>
                        </div>
                    </div>
                </li>
                <li class='dp-ItemIng'>
                    <div class='dp-Padding'>
                        <h4>为Ulord侧链开发基于LLVW的可修改智能合约</h4>
                        <p class='dp-word'>
                            Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean euismod bibendum laoreet. Proin gravida dolor sit amet lacus accumsan et viverra justo commodo. Proin sodales pulvinar tempor. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam fermentum, nulla luctus pharetra vulputate, felis tellus mollis orci, sed rhoncus sapien nunc eget.
                        </p>
                        <p class='dp-voteState'>
                            <span>投票</span>
                            
                        </p> 
                        <div class='dp-progressbar'>
                            <div class='dp-progress'></div>
                        </div>
                    </div>  
                    <div class='dp-consequenceWrap'>
                        <div class='dp-consequenceLf'>
                            <span>投票中：</span> &nbsp;
                            <span>378</span>
                        </div>
                        <div class='dp-consequenceRt'>
                            <span>来源于：</span> &nbsp;
                            <span>cyy</span>
                        </div>
                    </div>
                </li>
            </ul>
            
                <a class='dp-detailBtn'>查看详情</a>
            
        </div>                    
    </div>                    
    <div class='developerProjects'>
        <div class='container'>
            <h2>长期项目</h2> 
            <ul class='developerProjectsList'>
                <li>
                    <div class='dpl-name'>测试</div>
                    <div class='dpl-intro'>运营环境  负载均衡</div>
                    <div><a class='dpl-content'>参与Ulord公链的测试，不断优化公链</a></div>
                    <div><a class='dpl-looking'>查看详情</a></div>
                </li>
                <li>
                    <div class='dpl-name'>测试</div>
                    <div class='dpl-intro'>运营环境  负载均衡</div>
                    <div><a class='dpl-content'>参与Ulord公链的测试，不断优化公链</a></div>
                    <div><a class='dpl-looking'>查看详情</a></div>
                </li>
                <li>
                    <div class='dpl-name'>测试</div>
                    <div class='dpl-intro'>运营环境  负载均衡</div>
                    <div><a class='dpl-content'>参与Ulord公链的测试，不断优化公链</a></div>
                    <div><a class='dpl-looking'>查看详情</a></div>
                </li>
            </ul> 
        </div>
    </div>
    <the-task></the-task>
    <div class='developerFooter'>
        <div class='container'>
            <ul class='dlf-ul'>
                <li>
                    
                        <a>关于 Ulord 社区</a>
                    
                </li>
                <li>
                    
                        <a>文档中心</a>
                    
                </li>
                <li>
                    
                        <a>开发者</a>
                    
                </li>
                <li>
                    
                        <a>合作</a>
                    
                </li>
            </ul>
            <p class='dlf-copyright'>Copyright &copy; 2017-2018 Ulord.io</p>
        </div>
    </div>
    </div>
</div>
    
</template>

<script>
import {
  home
} from "@/api/api";
import topHeader from "../../components/topheader.vue"
import TheTask from "./TheTask.vue"
import { HappyScroll } from 'vue-happy-scroll'
import 'vue-happy-scroll/docs/happy-scroll.css'
export default {
  name: "developer",
  data() {
    return {
      data: {}
    }
  },
  components: { HappyScroll, topHeader, TheTask },
  created() {
    var that = this;
  }
};
</script>
<style rel="stylesheet/css" scoped>
.container {
  width: 1200px;
  margin: 0 auto;
  position: relative;
}
.developerBanner{
     width: 100%;
     height: 523px;
    background:url(../../assets/devloper-banner.png) no-repeat center; 
 }
 .developerClumn{
     width: 100%;
     height: 100px;
     background-color: #EEEEEE;
 }
 .developerClumnWrap>li{
     width: 25%;
     float: left;
 }
 .developerClumn h4{
     font-size: 16px;
     color: #282828;
     margin: 22px 0 13px;
 }
 .developerItem>li{
     float: left;
     padding-right: 20px;
 }
 .developerItem>li:last-child{
     padding-right: none;
 }
 .developerItem>li a{
     font-size: 14px;
     color: #999999; 
 }
 .developerTutorial{
     width: 100%;
     height: 654px;
     clear: both;
 }
 .developerTutorial h2{
     font-size: 50px;
     color: #282828;
     margin: 0 auto;
     text-align: center;
     margin: 100px 0 75px;
 }
 .dtItemContainer>li{
     width: 33%;
     float: left;
     margin: 0 auto;
     text-align: center
 }
 .dtItemContainer h4{
     font-size: 22px;
     color: #444444;
     margin: 30px 0 34px;
 }
 .dtItem-img01{
     display: inline-block;
     width: 105px;
     height: 99px;
    background: url(../../assets/devloper-tutorial-01.png) no-repeat center bottom;
 }
 .dtItem-img02{
     display: inline-block;
     width: 121px;
     height: 96px;
    background: url(../../assets/devloper-tutorial-02.png) no-repeat center bottom;
 }
 .dtItem-img03{
     display: inline-block;
     width: 126px;
     height: 96px;
    background: url(../../assets/devloper-tutorial-03.png) no-repeat center bottom;
 }
 .dtItemWrap li{
     padding-bottom: 16px;
 }
 .dtItemWrap li a{
     font-size: 18px;
     color: #444444;
 }
 .dtItemMore{
     margin: 0 auto;
     text-align: center;
     font-size: 14px;
     color: #999999;
     margin-top: 47px;
     display: block;
 }
 .dtItemMore:hover{
     color: #4F81F4;
 }
 
 /* 提案管理 */
 .developerProposal{
     padding-top: 134px;
     clear: both;
 }
 .developerProposal h2{
     margin: 0 auto;
     text-align: center;
     margin-bottom: 20px;
     font-size: 50px;
     color: #282828;
 }
 .developerProposalSlogan{
     margin: 0 auto;
     text-align: center;
     font-size: 16px;
     color: #444444;
     margin-bottom: 100px;
 }
 .dp-ListWrap{
     width: 100%;
     margin: 0 auto;
 }
 .dp-ListWrap li{
     box-sizing: border-box;
     margin: 0 auto;
     float: left;
     margin-right: 42px;
     width: 31%;
     height: 536px;
     background: #FFFFFF;
     box-shadow: 0 1px 12px 1px rgba(227,227,227,0.50);
     border-radius: 8px;
     margin-bottom: 20px;
 }
 .dp-ListWrap li:nth-child(3),.dp-ListWrap li:nth-child(6),.dp-ListWrap li:nth-child(9),.dp-ListWrap li:nth-child(12){
     margin-right: 0;
 }
 .dp-ListWrap li:last-child{
     margin-right: 0;
 }
 .dp-ListWrap li h4{
     font-size: 24px;
     color: #282828;
     line-height: 40px;
     padding-top: 81px;
     margin-bottom: 20px;
 }
 .dp-ListWrap li .dp-word{
     font-size: 14px;
     color: #282828;
     text-align: justify;
     height: 172px;
     overflow: hidden;
     line-height: 24px;
     margin-bottom: 30px;
 }
 .dp-ListWrap li .dp-Padding{
     padding: 0 30px;
 }
 /* 投票状态 start*/
 .dp-progressbar{
     width: 320px;
     height: 4px;
     background: #EEEEEE;
     border-radius: 47px;
     margin-top: 25px;
     margin-bottom: 34px;
 }
 /* 已通过 */
 .dp-ItemPassed .dp-voteState span{
     font-size: 14px;
     color: #4F81F4;
 }
 .dp-ItemPassed .dp-voteState b{
     font-size: 14px;
     color: #999999;
     font-weight: normal;
     margin-left: 5px;
 }
 .dp-ItemPassed .dp-progress{
     width: 176px;
     height: 6px;
     background: #4F81F4;
     border-radius: 47px;
 }
 /* 投票中 */
 .dp-ItemIng .dp-voteState span{
     font-size: 14px;
     color: #00DE8F;
 }
 .dp-ItemIng .dp-voteState b{
     display: none;
 }
 .dp-ItemIng .dp-progress{
     width: 176px;
     height: 6px;
     background: #3FD995;
     border-radius: 47px;
 }
 
 /* 未通过 */
 .dp-ItemFail .dp-voteState span{
     font-size: 14px;
     color: #F8B83A;
 }
 .dp-ItemFail .dp-voteState b{
     display: none;
 }
 .dp-ItemFail .dp-progress{
     width: 176px;
     height: 6px;
     background: #F8B83A;
     border-radius: 47px;
 }
 /* 投票状态 end*/
 
 .dp-consequenceWrap{
     border-top: 1px solid #EEEEEE;
     overflow: hidden;
 }
 .dp-consequenceLf{
     display: inline-block;
     width: 49%;
     height: 68px;
     line-height: 68px;
     margin: 0 auto;
     text-align: center;
     border-right: 1px solid #EEEEEE;
 }
 .dp-consequenceLf span{
     font-size: 14px;
     color: #4F81F4;
 }
 .dp-consequenceRt{
     display: inline-block;
     width: 49%;
     height: 68px;
     line-height: 68px;
     margin: 0 auto;
     text-align: center;
 }
 .dp-consequenceRt span{
     margin: 0 auto;
     text-align: center;
     font-size: 14px;
     color: #999999;
     overflow: hidden;
 }
 .dp-detailBtn{
     clear: both;
     display: block;
     width: 320px;
     height: 60px;
     margin: 0 auto;
     text-align: center;
     line-height: 60px;
     background: #4F80F4;
     border-radius: 4px;
     font-size: 18px;
     color: #FFFFFF;
     margin-bottom: 88px;
     position: relative;
     top: 70px;
 }
 /* 长期项目 */
 .developerProjects{
     width: 100%;
     padding-bottom: 100px;
 }
 .developerProjects h2{
     padding: 88px 0 90px;
     margin: 0 auto;
     text-align: center;
     font-size: 50px;
     color: #444444;
 }
 .developerProjectsList{
     width: 100%;
 }
 .developerProjectsList li{
     width: 100%;
     padding: 37px 0;
 }
 .developerProjectsList li:hover{
     background: #FFFFFF;
     box-shadow: 0 4px 8px 0 rgba(216,216,216,0.50);
 }
 .developerProjectsList li div{
     display: inline-block;
    
 }
 .dpl-name{
     width: 202px;
     margin: 0 auto;
     text-align: center;
     font-size: 24px;
     color: #282828;
 }
 .dpl-intro{
     width: 285px;
     margin: 0 auto;
     text-align: center;
     font-size: 16px;
     color: #333333;
 }
 .dpl-content{
     width: 291px;
     margin: 0 auto;
     text-align: center;
     overflow: hidden;
     white-space: nowrap;
     text-overflow: ellipsis;
     font-size: 16px;
     color: #333333;
 }
 
 .dpl-looking{
     width: 168px;
     height: 40px;
     line-height: 40px;
     text-align: center;
     background: #4F80F4;
     border-radius: 4px;
     font-size: 14px;
     color: #FFFFFF;
     margin-left: 216px;
     display: inline-block;
 }
 .developerFooter{
     width: 100%;
     height: 209px;
 }
 .developerFooter .container{
     border-top: 1px solid #999999;
 }
 .dlf-ul{
     margin: 0 auto;
     text-align: center;
     height: 132px;
     line-height: 132px;
     width: 378px;
 }
 .dlf-ul li{
     float: left;
     margin-right: 50px;
 }
 .dlf-ul li:last-child{
     margin-right: 0;
 }
 .dlf-ul li a{
     font-size: 14px;
     color: #666666;
 }
 .dlf-copyright{
     margin: 0 auto;
     text-align: center;
     font-size: 14px;
     color: #666666;
     clear: both;
 }
 
 /*====================================
    devloperTaskItem.jsx 
 /* =====================================*/
 


</style>