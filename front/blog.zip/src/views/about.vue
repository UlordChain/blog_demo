<template>
  <div class="commonContainer">
    <div class="header-wrap">
      <top-Header></top-Header>
    </div>
    <div class="container">
      <div class='aboutContainer'>
        <h2 class='aboutTitle'>
          《Ulord 社区章程》
        </h2>
        <div class='aboutRulesWrap'>
          <p>为了营造一个良好、和谐的交流环境，Ulord社区设立章程与准则，请您仔细阅读并遵守规范：</p>
        </div>
        <div class='aboutRulesWrap'>
          <h4 class='rulesTitle'>社区行为规则</h4>
          <ul class='rulesList'>
            <li class='rulesPaddingBttom'>
              <span>第1条     </span> 本社区所有开发者必须遵守中华人民共和国有关法律法规及本社区的规定。严禁发表造谣、侮辱、诽谤他人、煽动颠覆国家政权的言论和泄露国家机密；严禁发表暴力、淫秽、色情、迷信、宣扬种族歧视、破坏民族团结的言论和消息；开发者发表的文章仅代表其个人观点，与本社区无关；开发者须承担一切因自己的行为而直接或间接导致的民事、行政或刑事法律责任。在任何情况下，Ulorder开放平台社区均不对内容的准确性、合法性、完整性以及因内容而引起的任何损失、损害承担任何责任。开发者需自行把握。
            </li>
            <li class='rulesPaddingBttom'>
              <span>第2条     </span> 用户在Ulorder开发者社区注册、登录使用时，需要按照提示填写相关信息。在个人信息发生变动时，开发者及时修改相关信息。如果开发者提供的个人信息资料不准确，Ulorder开放平台保留结束开发者使用本站提供的网络服务的权利。在开发者需要帮助或者发生纠纷时，因不能确认开发者身份及其帐号的使用权利，不能够向开发者提供相应的帮助所带来的一切后果由开发者自己承担。
            </li>
            <li class='rulesPaddingBttom'>
              <span>第3条     </span> 未经开发者授权，Ulorder开放平台社区不会公开、编辑或透露其个人注册资料，除非基于下述原因：
              <ul class='rulesItemList'>
                <li>根据中华人民共和国法律或行政法规、规章的要求；</li>
                <li>根据中华人民共和国国家安全机构、公安部门及其他权力机构的要求，或根据相应的法律程序的要求；</li>
                <li>为维护Ulord及旗下的商标权及其它合法权益；</li>
                <li>在紧急情况下竭力维护开发者个人、其它社会个体和公众的安全；</li>
                <li>符合其他相关的要求。</li>
              </ul>
            </li>
            <li class='rulesPaddingBttom'>
              <span>第4条     </span> 开发者注册Ulorder账号并激活成功后，便成为Ulorder开放平台社区的正式成员。正式成员拥有本社区规定开发者所应享有的一切权限。开发者需对其用户名和密码安全负全部责任。每个开发者都应对以其所命名的账号发生的所有活动和事件负全部责任。开发者可随时变更其密码。开发者若发现任何非法使用帐号、密码或存在安全漏洞的情况，请立即通知Ulorder开放平台。
            </li>
          </ul>
        </div>
        <div class='aboutRulesWrap'>
          <h4 class='rulesTitle'>社区言论规则</h4>
          <ul class='rulesList'>
            <li class='rulesPaddingBttom'>
              <span>第1条     </span> 本社区开发者享有言论自由权利；开发者必须对自己的言论负责，开发者如要修改、删除自己发表的内容，需发帖@管理员 申请删除或者修改。
            </li>
            <li class='rulesPaddingBttom'>
              <span>第2条     </span> 本社区开发者的言行不得违反《计算机信息网络国际联网安全保护管理办法》、《互联网信息服务管理办法》、《互联网电子公告服务管理规定》、《维护互联网安全的决定》、《互联网新闻信息服务管理规定》等相关法律规定，不得在Ulorder开放平台社区发布、传播或以其它方式传送含有下列内容之一的信息：
              <br/> 本社区开发者不得发表包含以下内容的言论，否则本社区有权自行处理并不予通知用户：
              <ul class='rulesItemList'>
                <li>反对宪法所确定的基本原则的；</li>
                <li>危害国家安全，泄露国家秘密，颠覆国家政权，破坏国家统一的；</li>
                <li>损害国家荣誉和利益的；</li>
                <li>煽动民族仇恨、民族歧视、破坏民族团结的；</li>
                <li>破坏国家宗教政策，宣扬邪教和封建迷信的；</li>
                <li>散布谣言，扰乱社会秩序，破坏社会稳定的；</li>
                <li>散布淫秽、色情、赌博、暴力、凶杀、恐怖或者教唆犯罪的；</li>
                <li>侮辱或者诽谤他人，侵害他人合法权利的；</li>
                <li>煽动非法集会、结社、游行、示威、聚众扰乱社会秩序的；</li>
                <li>以非法民间组织名义活动的；</li>
                <li>含有虚假、有害、胁迫、侵害他人隐私、骚扰、侵害、中伤、粗俗、猥亵、或其它道德上令人反感的内容；</li>
                <li>侵犯他人知识产权或其他合法权益的；</li>
                <li>含有中国法律、法规、规章、条例以及任何具有法律效力之规范所限制或禁止的其它内容的。</li>
                <li class='rulesPaddingRight0'>恶性灌水帖子，即包含但不限于：
                  <ul class='rulesItemChild'>
                    <li>连续发布大量相同内容的主帖内容or回复</li>
                    <li>发布大量没有意义的文字图形</li>
                    <li>大量拷贝别人内容的灌水（解决别人技术问题的拷贝不在此列）</li>
                    <li>在技术问题中大量回复无关无用信息</li>
                  </ul>
                </li>
              </ul>
            </li>
            <li class='rulesPaddingBttom'>
              <span>第3条     </span> 本社区开发者在相关讨论区发表内容时，除遵守本条款外，还应遵守该讨论区、版主的相关规定。
            </li>
            <li class='rulesPaddingBttom'>
              <span>第4条     </span> 未经 Ulord 开放平台同意，禁止在本社区发布任何形式的广告。
            </li>
          </ul>
        </div>
        <div class='aboutRulesWrap'>
          <h4 class='rulesTitle'>社区管理规则</h4>
          <ul class='rulesList'>
            <li class='rulesPaddingBttom'>
              <span>第1条     </span> 本社区设定由社区管理员-版主组成的梯级管理体系。
            </li>
            <li class='rulesPaddingBttom'>
              <span>第2条     </span> 本社区管理员由Ulorder开放平台正式全职员工担任；管理员行使本社区全部站务管理职责和权力；版主由官方和开发者群体征集组成，凡是官方人员，将会展示『官』字样。其他社区版主及网友言论，由其本人承担，均与本社区立场无关。
            </li>
          </ul>
        </div>
        <div class='aboutRulesWrap'>
          <h4 class='rulesTitle'>附则</h4>
          <ul class='rulesList'>
            <li class='rulesPaddingBttom'>
              <span>第1条     </span> 本社区开发者之间通过社区相识、交往中所发生或可能发生的任何心理、生理上的伤害和经济上的纠纷与损失，Ulorder开放平台均不承担任何责任。
            </li>
            <li class='rulesPaddingBttom'>
              <span>第2条     </span> 本准则任何与国家法规有冲突的地方以国家法规为准，并可以重新修改准则。Ulorder开发平台对本准则拥有最终解释权。本条款自发布之日起生效！
            </li>
          </ul>
        </div>
        <!-- <div class='aboutRulesWrap'>
                            <h4 class='rulesTitle'>注册及登录</h4>
                            <ul class='rulesList'>
                                <li class='rulesPaddingBttom'>
                                    <span>第1项     </span>
                                    如何注册社区账号？注册 Ulord 账号，登录即可。
                                </li>
                                <li class='rulesPaddingBttom'>
                                    <span>第2项     </span>
                                    如何登录社区？如果您已经注册成功，点击“登陆”即可。如果您还未注册，请点击“注册”。
                                </li>
                                <li class='rulesPaddingBttom'>
                                    <span>第3项     </span>
                                    如果需要保持登录怎么办？可以勾选“记住密码”。
                                </li>
                                <li class='rulesPaddingBttom'>
                                    <span>第4项     </span>
                                    忘记登录密码怎么办？点击忘记密码，按照提示进行找回。
                                </li>
                            </ul>
                        </div>
                        <div class='aboutRulesWrap'>
                            <h4 class='rulesTitle'>发布及回复</h4>
                            <ul class='rulesList'>
                                <li class='rulesPaddingBttom'>
                                    <span>第1项     </span>
                                    如何发布内容？进入相关版块点击页面的"发布内容"。
                                    <ul class='rulesItemList'>
                                        <li>注：如果开发者在某版块被禁言，该帐号不能在该版发布内容。</li>
                                    </ul>
                                </li>
                                <li class='rulesPaddingBttom'>
                                    <span>第2项     </span>
                                    发布内容长度有何限制？发布内容尽量不少于10个字。
                                </li>
                                <li class='rulesPaddingBttom'>
                                    <span>第3项     </span>
                                    回复有何限制？每个开发者在同一主帖内最多可以连续回复3次。回复尽量不少于6个字。
                                </li>
                            </ul>
                        </div>
                        <div class='aboutRulesWrap'>
                            <h4 class='rulesTitle'>关于内容处理</h4>
                            <ul class='rulesList'>
                                <li class='rulesPaddingBttom'>
                                    <span>第1项     </span>
                                    主帖内容如何删除？社区管理员及版主可以删除帖子，您需要发帖 在标题 @管理员 删帖，正文说明删帖原因 以及链接。
                                </li>
                                <li class='rulesPaddingBttom'>
                                    <span>第2项     </span>
                                    如何删除回复？社区管理员及版主可以删除回复，您若需要删除同上操作方法。
                                </li>
                                <li class='rulesPaddingBttom'>
                                    <span>第3项     </span>
                                    置顶、加精如何实现？联系社区管理员 或者 版主 申请加精置顶。
                                </li>
                                <li class='rulesPaddingBttom'>
                                    <span>第4项     </span>
                                    如何将帖子内容加入推荐区？版主可以对帖子进行推荐，被推荐的帖子会进入该版的推荐【小编推荐】。
                                </li>
                            </ul>
                        </div>
                        <div class='aboutRulesWrap'>
                            <h4 class='rulesTitle'>等级与积分制度</h4>
                            <ul class='rulesList'>
                                <li class='rulesPaddingBttom'>
                                    <span>第1项     </span>
                                    什么是积分？
                                    <ul class='rulesItemList'>
                                        <li>开发者在社区中的行为，产生积分，是一种虚拟的财富，计入开发者账户中，可以衡量等级、赢取奖状/奖杯、也可以兑换成奖励。</li>
                                    </ul>
                                </li>
                                <li class='rulesPaddingBttom'>
                                    <span>第2项     </span>
                                    积分与等级
                                    <ul class='rulesItemList'>
                                        <li>共V1--V7等级，等级及对应积分如下，V5以上的用户，颁发证书和奖杯！</li>
                                    </ul>
                                </li>
                                <li class='rulesPaddingBttom'>
                                    <span>第3项     </span>
                                    积分的积累
                                    <ul class='rulesItemList'>
                                        <li>每ID每天积分上限：20积分</li>
                                        <li>通用积分制度</li>
                                        <li>额外积分奖励</li>
                                    </ul>
                                </li>
                                <li class='rulesPaddingBttom'>
                                    <span>第4项     </span>
                                    积分流失<br/>

                                    <ul class='rulesItemList'>
                                        <li>如果你发的帖子被删除，相应积分会扣减</li>
                                        <li>主帖被删除，扣减3分</li>
                                        <li>回帖被删除，扣减1分</li>
                                        <li>重复性水帖，扣减10分</li>
                                        <li>广告信息被删除，扣除50分</li>
                                    </ul>
                                </li>
                                <li class='rulesPaddingBttom'>
                                    <span>第5项     </span>
                                    积分兑换
                                    <ul class='rulesItemList'>
                                        <li>数量有限，具体以管理员发布的公告活动帖为准</li>
                                    </ul>
                                </li>
                            </ul>
                        </div> -->
      </div>
    </div>
  </div>
</template>

<script>
  export default {
    name: "a"
  };
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .commonContainer {
    height: 100%;
  }

  .aboutContainer {
    margin-top: 75px;
  }

  .aboutTitle {
    font-family: NotoSansHans-Bold;
    font-size: 24px;
    color: #444444;
    letter-spacing: 0.64px;
    margin: 0 auto;
    text-align: center;
    margin-bottom: 40px;
  }

  .aboutRulesWrap {
    margin-bottom: 40px;
  }

  .rulesTitle {
    font-size: 18px;
    color: #444444;
    letter-spacing: 0.48px;
    margin-bottom: 18px;
  }

  .rulesList {
    padding-left: 20px;
  }

  .rulesList li {
    font-size: 14px;
    color: #2a2a2a;
    letter-spacing: 0.37px;
    line-height: 28px;
    padding-right: 60px;
  }

  .rulesList li span {
    font-size: 16px;
    color: #444444;
  }

  .rulesPaddingBttom {
    padding-bottom: 25px;
  }

  .rulesItemList {
    padding-top: 15px;
  }

  .rulesItemList>li {
    padding-left: 52px;
    font-size: 14px;
    color: #666666;
    letter-spacing: 0.33px;
    line-height: 28px;
  }

  .rulesItemList>li::before {
    content: "";
    width: 8px;
    height: 8px;
    line-height: 28px;
    background-color: #d8d8d8;
    border-radius: 50%;
    display: inline-block;
    margin-right: 8px;
  }

  .rulesItemList>li.rulesPaddingRight0 {
    padding-right: 0;
  }

  .rulesItemChild {
    width: 100%;
    background: #f6f6f6;
    margin-top: 10px;
    padding: 20px 30px;
  }
</style>


