﻿## ulord-blog



## 运行

```
#下载

#安装依赖
npm i

#开发环境
npm run dev

#生产环境
npm run build

#运行地址
http://192.168.14.107:8182/   (可在 config 目录下的 index.js 文件中修改)

```
## 技术栈
Vue + Element + Sass + ES6 + Node.js





